chrome.runtime.onInstalled.addListener(() => {
  console.log('Audio Downloader Extension Installed');
});
